#include <iostream>
using namespace std;

int main() {
    float velocidadInicial, velocidadFinal, tiempo, aceleracion;
    
    cout << "====================================\n";
    cout << "   CALCULO DE ACELERACION\n";
    cout << "====================================\n\n";
    
    cout << "Ingrese la velocidad inicial (m/s): ";
    cin >> velocidadInicial;
    
    cout << "Ingrese la velocidad final (m/s): ";
    cin >> velocidadFinal;
    
    cout << "Ingrese el tiempo (segundos): ";
    cin >> tiempo;
    
    if (tiempo == 0) {
        cout << "\nError: El tiempo no puede ser cero.\n";
        cout << "No se puede calcular la aceleracion.\n";
    } else {
        aceleracion = (velocidadFinal - velocidadInicial) / tiempo;
        
        cout << "\n====================================\n";
        cout << "           RESULTADO\n";
        cout << "====================================\n";
        cout << "Velocidad inicial: " << velocidadInicial << " m/s\n";
        cout << "Velocidad final: " << velocidadFinal << " m/s\n";
        cout << "Tiempo: " << tiempo << " s\n";
        cout << "------------------------------------\n";
        cout << "Aceleracion: " << aceleracion << " m/s^2\n";
        cout << "====================================\n";
    }
    
    return 0;
}
